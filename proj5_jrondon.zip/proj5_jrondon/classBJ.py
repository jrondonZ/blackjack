

from classPC import PlayingCard
from classdeck import Deck
class BlackJack:

    dealerHand:[]
    playerHand:[]
    playingDeck:[]


    def __init__(self, dHand=[], pHand=[]):
        self.deck = Deck()
        self.deck.shuffle()
        self.dealerHand = dHand
        self.playerHand = pHand

    def initDeal(self,gwin,xposD,yposD,xposP,yposP):
        #deal cards to dealer
        dCard1 = self.deck.dealCard()
        self.dealerHand.append(dCard1)
        dCard2 = self.deck.dealCard()
        self.dealerHand.append(dCard2)
        for card in self.dealerHand:
            suit = card.getSuit()
            rank = card.getRank()
            imgDCard = Image(Point(xposD,yposD), "playingcard" + suit + str(rank) + ".gif")
            imgDCard.draw(gwin)
            xposD += 10

    hit(self, gwin, xPos, yPos)

    evaluateHand(self, hand)

    dealearPlays(self, gwin, xPos, yPos)
            
        
