

class Deck:
    suits = ["Spades", "Hearts", "clubs", "Diamonds"]
    ranks= ['King','Queen','Jack','Ace','10','9','8','7','6','5','4','3','2']
    def __init__(self):
        self.card = []
        for suit in suits:
            for rank in ranks:
                self.card.append(PlayingCard(suit,rank))

def main():
    deck = Deck()
    print(deck)

if __name__ == "main":
    main()
