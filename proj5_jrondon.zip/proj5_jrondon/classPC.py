#Josiah Rondon
#Project Asg 5 BlackJack, due Nov 21st
#Prof. Lee, Intro to Comp Sci


class PlayingCard:

    
    def __init__(self,rank,suit):

        self.rank = rank
        self.suit = suit
    
    def getRank(self):
        return self.rank
    def getSuit(self):
        return self.suit
    
    suits = ["Spades", "Hearts", "clubs", "Diamonds"]
    rnks= ['King','Queen','Jack','Ace','10','9','8','7','6','5','4','3','2']

    crdvalue = {'King': 10 , 'Queen':10, 'Jack':10, 'Ace':1 , '10':10 , '9':9 , '8':8 , '7':7 , '6':6 , '5':5 , '4':4 , '3':3 , '2':2}

    suits = ["Spades", "Hearts", "clubs", "Diamonds"]

def main():
    play = PlayingCard(10,"Heart")
    print(play.getRank())
    
if __name__== "__main__":
    main()




    


